# download mindone-assets
git clone https://github.com/wtomin/mindone-assets.git
mv mindone-assets/animatediff/__assets__/ ./
# remove the extra folders
rm -rf mindone-assets/
