Put your prompts here. Example:
```
 ├── prompts
 │   ├── 256
 │   ├── 512
 │   ├── 1024
 │   ├── 512_interp
 │   ├── 512_loop
 │   ├── ...
 ```
