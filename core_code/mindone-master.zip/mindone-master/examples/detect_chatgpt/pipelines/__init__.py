from mindone.pipelines.text_classifiers import BertMPUSequenceClassificationPipeline

__all__ = [
    "BertMPUSequenceClassificationPipeline",
]
