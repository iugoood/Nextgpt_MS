from mindone.pipelines.text_classifiers.BertMPUSequenceClassificationPipeline import (
    BertMPUSequenceClassificationPipeline,
)

__all__ = [
    "BertMPUSequenceClassificationPipeline",
]
