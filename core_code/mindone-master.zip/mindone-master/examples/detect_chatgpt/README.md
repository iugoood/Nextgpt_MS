# mindone
#### We provide an example of using a fine-tuned roberta model to distinguish between human-written text and ChatGPT generated text.
