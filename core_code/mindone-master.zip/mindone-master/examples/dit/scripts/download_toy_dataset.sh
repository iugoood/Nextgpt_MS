# download mindone-assets
git clone https://github.com/wtomin/mindone-assets.git
mkdir imagenet_samples/
mv mindone-assets/dit/imagenet_samples/images imagenet_samples/
# remove the extra folders
rm -rf mindone-assets/
