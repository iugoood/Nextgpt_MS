# download mindone-assets
git clone https://github.com/wtomin/mindone-assets.git
mkdir -p imagenet_samples
mv mindone-assets/dit/imagenet_samples/videos imagenet_samples/
# remove the extra folders
rm -rf mindone-assets/
